<?php
// データベース接続設定
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "calculator_db";

// データベース接続
$conn = new mysqli($servername, $username, $password);

// データベースが存在しない場合は作成
if ($conn->connect_error) {
    die("データベース接続エラー: " . $conn->connect_error);
}

// データベース作成
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) !== TRUE) {
    die("データベース作成エラー: " . $conn->error);
}

// データベースを選択
$conn->select_db($dbname);

// テーブル作成
$sql = "CREATE TABLE IF NOT EXISTS transactions (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(10) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) !== TRUE) {
    die("テーブル作成エラー: " . $conn->error);
}

// POSTリクエスト処理（計上・売上ボタンからのデータ保存）
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $type = $_POST["type"] ?? "";
    $amount = $_POST["amount"] ?? 0;
    $description = $_POST["description"] ?? "";
    
    if ($type && $amount) {
        $sql = "INSERT INTO transactions (type, amount, description) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sds", $type, $amount, $description);
        
        if ($stmt->execute()) {
            $response = ["success" => true, "message" => "{$type}として{$amount}円が記録されました"];
        } else {
            $response = ["success" => false, "message" => "エラー: " . $stmt->error];
        }
        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}

// 履歴取得API
if (isset($_GET["action"]) && $_GET["action"] == "get_history") {
    $limit = isset($_GET["limit"]) ? intval($_GET["limit"]) : 10;
    $sql = "SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $history = [];
    while ($row = $result->fetch_assoc()) {
        $history[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($history);
    exit;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riora</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'primary': '#6366f1', // インディゴ
                        'secondary': '#8b5cf6', // バイオレット
                        'accent': '#ec4899', // ピンク
                        'neutral': '#1f2937', // ダークグレー
                        'base': '#f3f4f6', // ライトグレー
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-900 flex flex-col items-center justify-center min-h-screen p-4">
    <div class="flex flex-col md:flex-row gap-4 w-full max-w-4xl">
        <!-- 電卓部分 -->
        <div class="w-full max-w-xs bg-gray-800 rounded-lg …">
            <!-- ディスプレイと結果コピー部分 -->
            <div class="p-4 border-b border-gray-700">
                <div class="flex items-center space-x-2">
                    <div class="relative flex-grow">
                        <input type="text" id="display" class="w-full text-right pr-4 text-2xl font-semibold p-2 bg-gray-700 text-white border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-primary" readonly value="0">
                    </div>
                    <button id="copyButton" onclick="copyResult()" class="bg-primary hover:bg-secondary text-white p-2 rounded border border-primary transition duration-300 flex-shrink-0" title="結果をコピー">
                        <i class="fas fa-copy"></i>
                    </button>
                </div>
                <div id="copyMessage" class="text-green-400 text-sm text-right mt-1 hidden">コピーしました!</div>
            </div>
            
            <!-- メモ入力欄 -->
            <div class="p-3 border-b border-gray-700">
                <input type="text" id="description" placeholder="メモ（任意）" class="w-full p-2 bg-gray-700 text-white border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-primary">
            </div>
            
            <!-- ボタン部分 -->
            <div class="p-3">
                <!-- 計上と売上ボタン -->
                <div class="grid grid-cols-2 gap-2 mb-3">
                    <button id="keijou" class="bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-lg transition duration-300">計上</button>
                    <button id="uriage" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-lg transition duration-300">売上</button>
                </div>
                
                <!-- 数字と機能ボタン -->
                <div class="grid grid-cols-4 gap-2">
                    <!-- 1行目 -->
                    <button onclick="appendToDisplay('7')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">7</button>
                    <button onclick="appendToDisplay('8')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">8</button>
                    <button onclick="appendToDisplay('9')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">9</button>
                    <button onclick="clearDisplay()" class="bg-accent hover:bg-pink-600 text-white font-bold py-6 rounded-lg transition duration-300">AC</button>
                    
                    <!-- 2行目 -->
                    <button onclick="appendToDisplay('4')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">4</button>
                    <button onclick="appendToDisplay('5')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">5</button>
                    <button onclick="appendToDisplay('6')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">6</button>
                    <button onclick="appendToDisplay('+')" class="bg-secondary hover:bg-purple-600 text-white font-bold py-6 rounded-lg transition duration-300">+</button>
                    
                    <!-- 3行目 -->
                    <button onclick="appendToDisplay('1')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">1</button>
                    <button onclick="appendToDisplay('2')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">2</button>
                    <button onclick="appendToDisplay('3')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">3</button>
                    <button onclick="appendToDisplay('*')" class="bg-secondary hover:bg-purple-600 text-white font-bold py-6 rounded-lg transition duration-300">×</button>
                    
                    <!-- 4行目 -->
                    <button onclick="appendToDisplay('0')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">0</button>
                    <button onclick="appendToDisplay('00')" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-6 rounded-lg transition duration-300">00</button>
                    <button onclick="calculateTax()" class="bg-amber-500 hover:bg-amber-600 text-white font-bold py-6 rounded-lg transition duration-300">Tax</button>
                    <button onclick="calculate()" class="bg-primary hover:bg-indigo-600 text-white font-bold py-6 rounded-lg transition duration-300">=</button>
                </div>
            </div>
        </div>
        
        <!-- 履歴表示部分 -->
        <div class="w-full bg-gray-800 rounded-lg shadow-2xl overflow-hidden border border-gray-700">
            <div class="p-4 border-b border-gray-700 flex justify-between items-center">
                <h2 class="text-xl font-semibold text-white">取引履歴</h2>
                <button onclick="refreshHistory()" class="bg-primary hover:bg-secondary text-white p-2 rounded transition duration-300" title="履歴を更新">
                    <i class="fas fa-sync-alt"></i>
                </button>
            </div>
            <div class="p-2 max-h-96 overflow-y-auto" id="historyContainer">
                <p class="text-gray-400 text-center p-4">履歴を読み込み中...</p>
            </div>
        </div>
    </div>

    <!-- 通知トースト -->
    <div id="toast" class="fixed bottom-4 right-4 bg-gray-800 text-white px-4 py-2 rounded-lg shadow-lg border border-gray-700 transform transition-transform duration-300 translate-y-20 opacity-0">
        メッセージが表示されます
    </div>

    <script>
        // 税率を設定（10%）
        const TAX_RATE = 0.1;
        
        function appendToDisplay(value) {
            const display = document.getElementById('display');
            if (display.value === '0' || display.value === 'Error') {
                display.value = value;
            } else {
                display.value += value;
            }
        }
        
        function clearDisplay() {
            document.getElementById('display').value = '0';
            document.getElementById('description').value = '';
        }
        
        function calculate() {
            try {
                const displayValue = document.getElementById('display').value;
                // evalを使用して計算（プロダクション環境では注意が必要）
                const result = eval(displayValue);
                document.getElementById('display').value = result;
            } catch (error) {
                document.getElementById('display').value = 'Error';
            }
        }
        
        function calculateTax() {
            try {
                const displayValue = document.getElementById('display').value;
                // 現在の値に税率をかける
                if (displayValue) {
                    const value = parseFloat(eval(displayValue));
                    const tax = value * TAX_RATE;
                    document.getElementById('display').value = (value + tax).toFixed(0);
                }
            } catch (error) {
                document.getElementById('display').value = 'Error';
            }
        }
        
        // 計算結果をコピーする機能
        function copyResult() {
            const display = document.getElementById('display');
            const copyMessage = document.getElementById('copyMessage');
            
            // 表示値を選択してコピー
            display.select();
            display.setSelectionRange(0, 99999); // モバイルデバイス用
            
            // クリップボードにコピー
            document.execCommand('copy');
            // または新しいClipboard APIを使用（対応ブラウザのみ）
            if (navigator.clipboard) {
                navigator.clipboard.writeText(display.value);
            }
            
            // コピー完了メッセージを表示
            copyMessage.classList.remove('hidden');
            
            // 2秒後にメッセージを非表示
            setTimeout(() => {
                copyMessage.classList.add('hidden');
            }, 2000);
        }
        
        // データベースに保存する関数
        async function saveTransaction(type) {
            try {
                const amount = eval(document.getElementById('display').value);
                const description = document.getElementById('description').value;
                
                if (isNaN(amount) || amount === '') {
                    showToast('有効な金額を入力してください');
                    return;
                }
                
                const formData = new FormData();
                formData.append('type', type);
                formData.append('amount', amount);
                formData.append('description', description);
                
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast(result.message);
                    refreshHistory();
                    clearDisplay();
                } else {
                    showToast('エラー: ' + result.message);
                }
            } catch (error) {
                showToast('エラーが発生しました: ' + error.message);
            }
        }
        
        // 計上ボタンと売上ボタンの処理
        document.getElementById('keijou').addEventListener('click', function() {
            saveTransaction('計上');
        });
        
        document.getElementById('uriage').addEventListener('click', function() {
            saveTransaction('売上');
        });

        // トースト通知を表示する関数
        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.classList.remove('translate-y-20', 'opacity-0');
            
            setTimeout(() => {
                toast.classList.add('translate-y-20', 'opacity-0');
            }, 3000);
        }
        
        // 履歴を取得して表示する関数
        async function refreshHistory() {
            try {
                const response = await fetch(`?action=get_history&limit=20`);
                const history = await response.json();
                
                const historyContainer = document.getElementById('historyContainer');
                
                if (history.length === 0) {
                    historyContainer.innerHTML = '<p class="text-gray-400 text-center p-4">履歴はありません</p>';
                    return;
                }
                
                let html = '<div class="overflow-x-auto">';
                html += '<table class="min-w-full text-sm">';
                html += '<thead><tr class="bg-gray-700"><th class="px-4 py-2 text-left text-white">日時</th><th class="px-4 py-2 text-left text-white">種類</th><th class="px-4 py-2 text-right text-white">金額</th><th class="px-4 py-2 text-left text-white">メモ</th></tr></thead>';
                html += '<tbody>';
                
                history.forEach(item => {
                    const date = new Date(item.created_at).toLocaleString('ja-JP');
                    const typeClass = item.type === '計上' ? 'text-green-400' : 'text-blue-400';
                    
                    html += `<tr class="border-t border-gray-700">`;
                    html += `<td class="px-4 py-2 text-gray-300">${date}</td>`;
                    html += `<td class="px-4 py-2 ${typeClass} font-medium">${item.type}</td>`;
                    html += `<td class="px-4 py-2 text-right text-white">${Number(item.amount).toLocaleString()} 円</td>`;
                    html += `<td class="px-4 py-2 text-gray-300">${item.description || '-'}</td>`;
                    html += `</tr>`;
                });
                
                html += '</tbody></table></div>';
                historyContainer.innerHTML = html;
            } catch (error) {
                document.getElementById('historyContainer').innerHTML = `<p class="text-red-400 text-center p-4">エラー: ${error.message}</p>`;
            }
        }

        // キーボード入力対応
        document.addEventListener('keydown', function(event) {
            const key = event.key;
            
            // 数字キーと演算子キー
            if (/[0-9+*=]/.test(key)) {
                appendToDisplay(key);
            }
            // バックスペース（削除）
            else if (key === 'Backspace') {
                const display = document.getElementById('display');
                display.value = display.value.slice(0, -1);
                if (display.value === '') {
                    display.value = '0';
                }
            }
            // Enter（計算実行）
            else if (key === 'Enter') {
                calculate();
            }
            // Escape（クリア）
            else if (key === 'Escape') {
                clearDisplay();
            }
        });
        
        // ページ読み込み時に履歴を表示
        window.addEventListener('load', refreshHistory);
    </script>
</body>
</html>